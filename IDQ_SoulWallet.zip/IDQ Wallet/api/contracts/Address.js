// Tokenのコントラクトアドレス
const MYTOKEN_ADDRESS = "0x03816f4A868A3e11CE6D2e71811D78fF91477ee7";
// Factoryコントラクトのアドレス
const FACTORY_ADDRESS = "0x8e1e5f5Ee60AbBEf21Ae80b5295D97b6f50227f7";

module.exports = { 
      MYTOKEN_ADDRESS,
      FACTORY_ADDRESS
};